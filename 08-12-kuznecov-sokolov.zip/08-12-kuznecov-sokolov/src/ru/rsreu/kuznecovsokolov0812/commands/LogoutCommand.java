package ru.rsreu.kuznecovsokolov0812.commands;

import javax.servlet.http.HttpServletRequest;

import ru.rsreu.kuznecovsokolov0812.utils.ConfigurationManager;

public class LogoutCommand implements ActionCommand {

	@Override
	public String execute(HttpServletRequest request) {
		String page = ConfigurationManager.getProperty("path.page.index");
		request.getSession().invalidate();
		return page;
	}

}
