package ru.rsreu.kuznecovsokolov0812.utils;

import java.util.ResourceBundle;

public class ConfigurationManager {
	
	private final static ResourceBundle resourceBundle = ResourceBundle.getBundle("resources.configuration");
	private ConfigurationManager() {
	}

	public static String getProperty(String key) {
		return resourceBundle.getString(key);
	}
}
